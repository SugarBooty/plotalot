#include "plotJob.hpp"
#include "global_config.hpp"

#include <string>
#include <stdexcept>

// public methods

PlotJob::PlotJob(configMap config, bool restore = false) {
    jobConfig = config;
    jobRestore = restore;
}

void begin() {

}

void suspend() {

}

void resume() {

}

void kill() {

}

PlotJob::configMap PlotJob::getConfigMap() {

}



// private methods

std::string PlotJob::buildCommand() {
    std::string command;
    command += getVal(config::CHIA_COMMAND);
    command += " -n 1"; // sets the amount of plots generated to 1 to allow proper functionality of this program
    command += " -r " + getVal(config::THREADS);
    command += " -u " + getVal(config::BUCKETS);
    command += " -t " + getVal(config::TEMP_DIR);
    command += " -d " + getVal(config::DEST_DIR);
    command += " -c " + getVal(config::POOL_CONTRACT_ADDRESS);
    command += " -f " + getVal(config::FARMER_PUBLIC_KEY);
    if ( getVal(config::THREAD_MULTIPLIER) != "false" )
        command += " -K " + getVal(config::THREAD_MULTIPLIER);
    if ( getVal(config::BUCKETS_3_4) != "false" )
        command += " -v " + getVal(config::BUCKETS_3_4);
    if ( getVal(config::TEMP_RAM_DIR) != "false" )
        command += " -2 " + getVal(config::TEMP_RAM_DIR);

    plotCommand = command;
    return plotCommand;
}

std::string PlotJob::getVal(const std::string& key){
    if ( jobConfig.find(key) != jobConfig.end() )
        return jobConfig[key];
    else
        throw(std::invalid_argument("No key called " + key + " found in config. Check the config file for typos."));
}